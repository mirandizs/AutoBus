﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.Security.Cryptography;

namespace Admin
{
    public partial class Form1 : Form
    {
        ligacaoDB db = new ligacaoDB();

        public Form1()
        {
            InitializeComponent();
            db.inicializa();

            label4.Visible = false;
        }

        private void btSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btInfo_Click(object sender, EventArgs e)
        {

        }

        private void btEntrar_Click(object sender, EventArgs e)
        {
            //caso os campos não estejam todos completos ou sejam nulos
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                label4.Text = "*Todos os campos devem ser preenchidos.";
                label4.Visible = true;
            }

            else
            {
                label4.Visible = false;

                db.open_connection();

                string email = textBox1.Text;

                // atualizar a query para comparar o hash
                string query = "SELECT COUNT(*), NIF, tipo_utilizador FROM utilizadores WHERE email = @email";

                MySqlCommand verificacao = new MySqlCommand(query, db.connection);
                verificacao.Parameters.AddWithValue("@email", email);

                MySqlDataReader ler = verificacao.ExecuteReader();

                //para verificar a palavra-passe
                if (ler.Read())
                {
                    int nif = ler.GetInt32(0);

                    ler.Close();

                    query = "SELECT * FROM utilizadores WHERE email = @email AND pass = PASSWORD(@pass)";

                    verificacao = new MySqlCommand(query, db.connection);
                    verificacao.Parameters.AddWithValue("@email", email);
                    verificacao.Parameters.AddWithValue("@pass", textBox2.Text);

                    ler = verificacao.ExecuteReader();

                    if (!ler.Read())
                    {
                        label4.Text = "*Palavra-passe incorreta.";
                        label4.Visible = true;

                        ler.Close();
                        return;
                    }

                    //para verificar o email
                    else
                    {
                        label4.Visible = false;

                        int verificacao2 = ler.GetInt32(0); //guardar o 1º item da coluna

                        if (verificacao2 <= 0)
                        {
                            MessageBox.Show("Email incorreto ou a conta não existe.", "AutoBus", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }


                        int tipo = ler.GetInt32(7); // Obter o tipo de utilizador

                        ler.Close();

                        if (tipo != 0)
                        {
                            MessageBox.Show("Acesso permitido apenas para administradores.", "AutoBus", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }

                        else
                        {
                            //mensagem para confirmar os dados e aceder o form principal
                            MessageBoxButtons botao = MessageBoxButtons.OK;
                            System.Windows.Forms.DialogResult resultado;

                            resultado = MessageBox.Show(this, "Bem vindo(a) de volta!", "AutoBus", botao);

                            if (resultado == System.Windows.Forms.DialogResult.OK)
                            {
                                Principal principal = new Principal(nif);
                                principal.Show();

                                //fechar a ligação à BD
                                db.close_connection();

                                textBox1.Clear();
                                textBox2.Clear();
                            }
                        }
                    }
                    ler.Close();
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }
    }
}
