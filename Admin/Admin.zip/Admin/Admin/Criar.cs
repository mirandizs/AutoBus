﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin
{
    public partial class Criar : Form
    {
        public Criar(string opcao)
        {
            InitializeComponent();

            TopMost = false;

            panelAutocarro.Visible = false;
            panelUtilizador.Visible = false;

            // Lógica para controlar a visibilidade dos painéis
            if (opcao == "autocarros")
            {
                panelAutocarro.Visible = true;
                panelUtilizador.Visible = false;
            }
            else if (opcao == "utilizadores")
            {
                panelUtilizador.Visible = true;
                panelAutocarro.Visible = false;
            }
        }

        private void btSairUtilizador_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btCriarUtilizador_Click(object sender, EventArgs e)
        {

        }

        private void btSairAutocarro_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
