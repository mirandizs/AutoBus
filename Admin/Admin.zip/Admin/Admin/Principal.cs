﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using Mysqlx.Crud;

namespace Admin
{
    public partial class Principal : Form
    {
        ligacaoDB db = new ligacaoDB();
        private int nif;
        bool menuExpandir;
        bool transicaoLatExpandir;

        public Principal(int nif)
        {
            InitializeComponent();
            db.inicializa();
            this.nif = nif;

            //flowLayoutPanelMenu.Width = 0;

            flowLayoutPanelMenu.Visible = false;

            panelUtilizadores.Visible = false;
            panelAutocarros.Visible = false;

            TopMost = false;
        }

        private void Principal_Load(object sender, EventArgs e)
        {
            if (db.open_connection())
            {
                db.inicializa();
                db.open_connection();

                string query = "SELECT * FROM utilizadores WHERE nif = @nif";

                MySqlCommand info = new MySqlCommand(query, db.connection);

                info.Parameters.AddWithValue("@nif", nif);

                MySqlDataReader ler = info.ExecuteReader();

                ler.Close();
            }
        }

        //BOTAO SAIR
        private void btSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        //FUNÇÕES PARA A ANIMAÇÃO DO MENU
        private void transicao_Tick(object sender, EventArgs e)
        {
            if (menuExpandir)
            {
                //se o menu expandir, minimiza
                flowLayoutPanelMenu.Width -= 10;

                if (flowLayoutPanelMenu.Width == flowLayoutPanelMenu.MinimumSize.Width)
                {
                    menuExpandir = false;
                    transicao.Stop();
                }
                else
                {
                    flowLayoutPanelMenu.Width += 10;

                    if (flowLayoutPanelMenu.Width == flowLayoutPanelMenu.MinimumSize.Width)
                    {
                        menuExpandir = true;
                        transicao.Stop();
                    }
                }
            }
        }

        private void transicaoLateral_Tick(object sender, EventArgs e)
        {
            if (transicaoLatExpandir == true)
            {
                flowLayoutPanelMenu.Width -= 10; // Incremento maior para velocidade

                if (flowLayoutPanelMenu.Width <= 0)
                {
                    transicaoLatExpandir = false;
                    transicaoLateral.Stop();
                }

                panelUtilizadores.Visible = false;
                panelAutocarros.Visible = false;
            }
            else
            {
                flowLayoutPanelMenu.Width += 10; // Incremento maior para velocidade

                if (flowLayoutPanelMenu.Width >= 144)
                {
                    transicaoLatExpandir = true;
                    transicaoLateral.Stop();
                }
            }
        }


        private void btMenu_Click_1(object sender, EventArgs e)
        {
            transicaoLateral.Start();
            flowLayoutPanelMenu.Visible = true;
        }

        private void flowLayoutPanelMenu_Paint(object sender, PaintEventArgs e)
        {

        }


        //PARA O PANEL DE UTILIZADORES -------------------------------------------------------------------------
        private void btUtilizadores_Click(object sender, EventArgs e)
        {
            panelUtilizadores.Visible = true;
            panelAutocarros.Visible = false;
        }

        private void btEditarUtilizadores_Click(object sender, EventArgs e)
        {
            using (Editar editar = new Editar("utilizadores")) // `using` garante que o objeto será descartado
            {
                this.Hide();
                editar.ShowDialog();
            }
            this.Show();
        }

        private void btCriarUtilizador_Click(object sender, EventArgs e)
        {
            using (Criar criar = new Criar("utilizadores")) // `using` garante que o objeto será descartado
            {
                this.Hide();
                criar.ShowDialog();
            }
            this.Show();
        }


        //o botão de eliminar os utilizadores será apenas para desativá-los. não haverá qualquer tipo de alteração na base de dados, neste caso, que elimine da base de dados.
        //o ficar "desativado" só apagará do daatagridview, ou seja, deixá-lo invisível. 
        private void btDesativarUtilizador_Click(object sender, EventArgs e)
        {

        }

        private void btLimparUtilizadores_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            dataGridView1.ClearSelection();
        }

        private void btPesquisarUtilizadores_Click(object sender, EventArgs e)
        {
            db.open_connection();

            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            // Definir as colunas do DataGridView
            dataGridView1.Columns.Add("NIF", "NIF");
            dataGridView1.Columns.Add("Nome", "Nome");
            dataGridView1.Columns.Add("Nascimento", "Data de Nascimento");
            dataGridView1.Columns.Add("Telefone", "Telemóvel");
            dataGridView1.Columns.Add("Email", "Email");
            dataGridView1.Columns.Add("Pass", "Palavra-Passe");
            dataGridView1.Columns.Add("Tipo_utilizador", "Tipos de utilizador");

            string nome = textBox1.Text;

            string query = "SELECT * FROM utilizadores WHERE nome = @nome";

            if (db.open_connection())
            {
                MySqlCommand cmd = new MySqlCommand(query, db.connection);
                cmd.Parameters.AddWithValue("@nome", nome);

                MySqlDataReader dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    dataGridView1.Rows.Add(
                    dataReader["NIF"].ToString(),
                    dataReader["nome"].ToString(),
                    DateTime.Parse(dataReader["nascimento"].ToString()).ToString("yyyy-MM-dd"),
                    dataReader["telefone"].ToString(),
                    dataReader["email"].ToString(),
                    dataReader["pass"].ToString()
                    );
                }
                db.close_connection();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
                
        }


        //PARA O PANEL DE AUTOCARROS -------------------------------------------------------------------------- 
        private void btAutocarros_Click_1(object sender, EventArgs e)
        {
            panelAutocarros.Visible = true;
            panelUtilizadores.Visible = false;
        }

        private void panelAutocarros_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btEditarAutocarro_Click(object sender, EventArgs e)
        {
            using (Editar editar = new Editar("autocarros")) // `using` garante que o objeto será descartado
            {
                this.Hide();
                editar.ShowDialog();
            }
            this.Show();
        }

        private void btAdicionarAutoC_Click(object sender, EventArgs e)
        {
            using (Criar criar = new Criar("autocarros")) // `using` garante que o objeto será descartado
            {
                this.Hide();
                criar.ShowDialog();
            }
            this.Show();
        }

        private void btDesativarAuto_Click(object sender, EventArgs e)
        {

        }

        private void btCriarRotas_Click(object sender, EventArgs e)
        {

        }

        private void btLimparAutocarro_Click(object sender, EventArgs e)
        {

        }
    }
}
