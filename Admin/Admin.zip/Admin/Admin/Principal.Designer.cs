﻿namespace Admin
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.flowLayoutPanelMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btUtilizadores = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btAutocarros = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btMenu = new System.Windows.Forms.Button();
            this.btSair = new System.Windows.Forms.Button();
            this.panelUtilizadores = new System.Windows.Forms.Panel();
            this.btEditarUtilizadores = new System.Windows.Forms.Button();
            this.btDesativarUtilizador = new System.Windows.Forms.Button();
            this.btLimparUtilizadores = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btCriarUtilizador = new System.Windows.Forms.Button();
            this.btPesquisarUtilizadores = new System.Windows.Forms.Button();
            this.transicao = new System.Windows.Forms.Timer(this.components);
            this.transicaoLateral = new System.Windows.Forms.Timer(this.components);
            this.panelAutocarros = new System.Windows.Forms.Panel();
            this.btCriarRotas = new System.Windows.Forms.Button();
            this.btAdicionarAutoC = new System.Windows.Forms.Button();
            this.btLimparAutocarro = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btDesativarAuto = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btEditarAutocarro = new System.Windows.Forms.Button();
            this.flowLayoutPanelMenu.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelUtilizadores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panelAutocarros.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanelMenu
            // 
            this.flowLayoutPanelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.flowLayoutPanelMenu.Controls.Add(this.panel2);
            this.flowLayoutPanelMenu.Controls.Add(this.panel4);
            this.flowLayoutPanelMenu.Controls.Add(this.panel5);
            this.flowLayoutPanelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanelMenu.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanelMenu.Margin = new System.Windows.Forms.Padding(4);
            this.flowLayoutPanelMenu.Name = "flowLayoutPanelMenu";
            this.flowLayoutPanelMenu.Padding = new System.Windows.Forms.Padding(0, 37, 0, 0);
            this.flowLayoutPanelMenu.Size = new System.Drawing.Size(189, 474);
            this.flowLayoutPanelMenu.TabIndex = 4;
            this.flowLayoutPanelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanelMenu_Paint);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(4, 41);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 47);
            this.panel2.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.panel4.Controls.Add(this.btUtilizadores);
            this.panel4.Location = new System.Drawing.Point(4, 96);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(213, 53);
            this.panel4.TabIndex = 10;
            // 
            // btUtilizadores
            // 
            this.btUtilizadores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btUtilizadores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btUtilizadores.FlatAppearance.BorderSize = 0;
            this.btUtilizadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btUtilizadores.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btUtilizadores.ForeColor = System.Drawing.Color.White;
            this.btUtilizadores.Location = new System.Drawing.Point(-9, 0);
            this.btUtilizadores.Margin = new System.Windows.Forms.Padding(4);
            this.btUtilizadores.Name = "btUtilizadores";
            this.btUtilizadores.Size = new System.Drawing.Size(191, 46);
            this.btUtilizadores.TabIndex = 2;
            this.btUtilizadores.Text = "    Utilizadores";
            this.btUtilizadores.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btUtilizadores.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btUtilizadores.UseVisualStyleBackColor = false;
            this.btUtilizadores.Click += new System.EventHandler(this.btUtilizadores_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.panel5.Controls.Add(this.btAutocarros);
            this.panel5.Location = new System.Drawing.Point(4, 157);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(213, 53);
            this.panel5.TabIndex = 11;
            // 
            // btAutocarros
            // 
            this.btAutocarros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btAutocarros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btAutocarros.FlatAppearance.BorderSize = 0;
            this.btAutocarros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAutocarros.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btAutocarros.ForeColor = System.Drawing.Color.White;
            this.btAutocarros.Location = new System.Drawing.Point(-8, 0);
            this.btAutocarros.Margin = new System.Windows.Forms.Padding(4);
            this.btAutocarros.Name = "btAutocarros";
            this.btAutocarros.Size = new System.Drawing.Size(189, 46);
            this.btAutocarros.TabIndex = 2;
            this.btAutocarros.Text = "    Autocarros";
            this.btAutocarros.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAutocarros.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btAutocarros.UseVisualStyleBackColor = false;
            this.btAutocarros.Click += new System.EventHandler(this.btAutocarros_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btMenu);
            this.panel1.Controls.Add(this.btSair);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(983, 48);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(421, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 34);
            this.label1.TabIndex = 3;
            this.label1.Text = "AutoBus";
            // 
            // btMenu
            // 
            this.btMenu.BackColor = System.Drawing.Color.Transparent;
            this.btMenu.BackgroundImage = global::Admin.Properties.Resources.menuB;
            this.btMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btMenu.FlatAppearance.BorderSize = 0;
            this.btMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMenu.Location = new System.Drawing.Point(5, 5);
            this.btMenu.Margin = new System.Windows.Forms.Padding(4);
            this.btMenu.Name = "btMenu";
            this.btMenu.Size = new System.Drawing.Size(60, 39);
            this.btMenu.TabIndex = 2;
            this.btMenu.UseVisualStyleBackColor = false;
            this.btMenu.Click += new System.EventHandler(this.btMenu_Click_1);
            // 
            // btSair
            // 
            this.btSair.BackColor = System.Drawing.Color.Transparent;
            this.btSair.BackgroundImage = global::Admin.Properties.Resources.xB;
            this.btSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btSair.FlatAppearance.BorderSize = 0;
            this.btSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.btSair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.btSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSair.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btSair.Location = new System.Drawing.Point(912, -1);
            this.btSair.Margin = new System.Windows.Forms.Padding(4);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(67, 49);
            this.btSair.TabIndex = 2;
            this.btSair.UseVisualStyleBackColor = false;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // panelUtilizadores
            // 
            this.panelUtilizadores.Controls.Add(this.btEditarUtilizadores);
            this.panelUtilizadores.Controls.Add(this.btDesativarUtilizador);
            this.panelUtilizadores.Controls.Add(this.btLimparUtilizadores);
            this.panelUtilizadores.Controls.Add(this.dataGridView1);
            this.panelUtilizadores.Controls.Add(this.textBox1);
            this.panelUtilizadores.Controls.Add(this.label2);
            this.panelUtilizadores.Controls.Add(this.btCriarUtilizador);
            this.panelUtilizadores.Controls.Add(this.btPesquisarUtilizadores);
            this.panelUtilizadores.Location = new System.Drawing.Point(189, 47);
            this.panelUtilizadores.Margin = new System.Windows.Forms.Padding(4);
            this.panelUtilizadores.Name = "panelUtilizadores";
            this.panelUtilizadores.Size = new System.Drawing.Size(792, 427);
            this.panelUtilizadores.TabIndex = 5;
            // 
            // btEditarUtilizadores
            // 
            this.btEditarUtilizadores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btEditarUtilizadores.FlatAppearance.BorderSize = 0;
            this.btEditarUtilizadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEditarUtilizadores.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btEditarUtilizadores.ForeColor = System.Drawing.Color.White;
            this.btEditarUtilizadores.Location = new System.Drawing.Point(25, 379);
            this.btEditarUtilizadores.Margin = new System.Windows.Forms.Padding(4);
            this.btEditarUtilizadores.Name = "btEditarUtilizadores";
            this.btEditarUtilizadores.Size = new System.Drawing.Size(163, 28);
            this.btEditarUtilizadores.TabIndex = 12;
            this.btEditarUtilizadores.Text = "Editar utilizador";
            this.btEditarUtilizadores.UseVisualStyleBackColor = false;
            this.btEditarUtilizadores.Click += new System.EventHandler(this.btEditarUtilizadores_Click);
            // 
            // btDesativarUtilizador
            // 
            this.btDesativarUtilizador.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btDesativarUtilizador.FlatAppearance.BorderSize = 0;
            this.btDesativarUtilizador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDesativarUtilizador.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btDesativarUtilizador.ForeColor = System.Drawing.Color.White;
            this.btDesativarUtilizador.Location = new System.Drawing.Point(371, 379);
            this.btDesativarUtilizador.Margin = new System.Windows.Forms.Padding(4);
            this.btDesativarUtilizador.Name = "btDesativarUtilizador";
            this.btDesativarUtilizador.Size = new System.Drawing.Size(209, 28);
            this.btDesativarUtilizador.TabIndex = 11;
            this.btDesativarUtilizador.Text = "Desativar utilizador";
            this.btDesativarUtilizador.UseVisualStyleBackColor = false;
            this.btDesativarUtilizador.Click += new System.EventHandler(this.btDesativarUtilizador_Click);
            // 
            // btLimparUtilizadores
            // 
            this.btLimparUtilizadores.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btLimparUtilizadores.BackgroundImage = global::Admin.Properties.Resources.limpar;
            this.btLimparUtilizadores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btLimparUtilizadores.FlatAppearance.BorderSize = 0;
            this.btLimparUtilizadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLimparUtilizadores.Location = new System.Drawing.Point(676, 308);
            this.btLimparUtilizadores.Margin = new System.Windows.Forms.Padding(4);
            this.btLimparUtilizadores.Name = "btLimparUtilizadores";
            this.btLimparUtilizadores.Size = new System.Drawing.Size(51, 38);
            this.btLimparUtilizadores.TabIndex = 10;
            this.btLimparUtilizadores.UseVisualStyleBackColor = false;
            this.btLimparUtilizadores.Click += new System.EventHandler(this.btLimparUtilizadores_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(80, 85);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(649, 262);
            this.dataGridView1.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(445, 21);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(167, 32);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.label2.Location = new System.Drawing.Point(19, 21);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 39);
            this.label2.TabIndex = 4;
            this.label2.Text = "Utilizadores";
            // 
            // btCriarUtilizador
            // 
            this.btCriarUtilizador.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btCriarUtilizador.FlatAppearance.BorderSize = 0;
            this.btCriarUtilizador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCriarUtilizador.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btCriarUtilizador.ForeColor = System.Drawing.Color.White;
            this.btCriarUtilizador.Location = new System.Drawing.Point(205, 379);
            this.btCriarUtilizador.Margin = new System.Windows.Forms.Padding(4);
            this.btCriarUtilizador.Name = "btCriarUtilizador";
            this.btCriarUtilizador.Size = new System.Drawing.Size(145, 28);
            this.btCriarUtilizador.TabIndex = 3;
            this.btCriarUtilizador.Text = "Criar utilizador";
            this.btCriarUtilizador.UseVisualStyleBackColor = false;
            this.btCriarUtilizador.Click += new System.EventHandler(this.btCriarUtilizador_Click);
            // 
            // btPesquisarUtilizadores
            // 
            this.btPesquisarUtilizadores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btPesquisarUtilizadores.FlatAppearance.BorderSize = 0;
            this.btPesquisarUtilizadores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPesquisarUtilizadores.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btPesquisarUtilizadores.ForeColor = System.Drawing.Color.White;
            this.btPesquisarUtilizadores.Image = global::Admin.Properties.Resources.lupaB;
            this.btPesquisarUtilizadores.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btPesquisarUtilizadores.Location = new System.Drawing.Point(635, 21);
            this.btPesquisarUtilizadores.Margin = new System.Windows.Forms.Padding(4);
            this.btPesquisarUtilizadores.Name = "btPesquisarUtilizadores";
            this.btPesquisarUtilizadores.Size = new System.Drawing.Size(141, 32);
            this.btPesquisarUtilizadores.TabIndex = 1;
            this.btPesquisarUtilizadores.Text = "  Pesquisar";
            this.btPesquisarUtilizadores.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btPesquisarUtilizadores.UseVisualStyleBackColor = false;
            this.btPesquisarUtilizadores.Click += new System.EventHandler(this.btPesquisarUtilizadores_Click);
            // 
            // transicao
            // 
            this.transicao.Interval = 10;
            this.transicao.Tick += new System.EventHandler(this.transicao_Tick);
            // 
            // transicaoLateral
            // 
            this.transicaoLateral.Interval = 10;
            this.transicaoLateral.Tick += new System.EventHandler(this.transicaoLateral_Tick);
            // 
            // panelAutocarros
            // 
            this.panelAutocarros.Controls.Add(this.btCriarRotas);
            this.panelAutocarros.Controls.Add(this.btAdicionarAutoC);
            this.panelAutocarros.Controls.Add(this.btLimparAutocarro);
            this.panelAutocarros.Controls.Add(this.dataGridView2);
            this.panelAutocarros.Controls.Add(this.btDesativarAuto);
            this.panelAutocarros.Controls.Add(this.label3);
            this.panelAutocarros.Controls.Add(this.btEditarAutocarro);
            this.panelAutocarros.Location = new System.Drawing.Point(189, 47);
            this.panelAutocarros.Margin = new System.Windows.Forms.Padding(4);
            this.panelAutocarros.Name = "panelAutocarros";
            this.panelAutocarros.Size = new System.Drawing.Size(792, 427);
            this.panelAutocarros.TabIndex = 6;
            this.panelAutocarros.Paint += new System.Windows.Forms.PaintEventHandler(this.panelAutocarros_Paint);
            // 
            // btCriarRotas
            // 
            this.btCriarRotas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btCriarRotas.FlatAppearance.BorderSize = 0;
            this.btCriarRotas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCriarRotas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btCriarRotas.ForeColor = System.Drawing.Color.White;
            this.btCriarRotas.Location = new System.Drawing.Point(632, 379);
            this.btCriarRotas.Margin = new System.Windows.Forms.Padding(4);
            this.btCriarRotas.Name = "btCriarRotas";
            this.btCriarRotas.Size = new System.Drawing.Size(124, 28);
            this.btCriarRotas.TabIndex = 20;
            this.btCriarRotas.Text = "Rotas";
            this.btCriarRotas.UseVisualStyleBackColor = false;
            this.btCriarRotas.Click += new System.EventHandler(this.btCriarRotas_Click);
            // 
            // btAdicionarAutoC
            // 
            this.btAdicionarAutoC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btAdicionarAutoC.FlatAppearance.BorderSize = 0;
            this.btAdicionarAutoC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAdicionarAutoC.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btAdicionarAutoC.ForeColor = System.Drawing.Color.White;
            this.btAdicionarAutoC.Location = new System.Drawing.Point(208, 379);
            this.btAdicionarAutoC.Margin = new System.Windows.Forms.Padding(4);
            this.btAdicionarAutoC.Name = "btAdicionarAutoC";
            this.btAdicionarAutoC.Size = new System.Drawing.Size(195, 28);
            this.btAdicionarAutoC.TabIndex = 19;
            this.btAdicionarAutoC.Text = "Adicionar autocarro";
            this.btAdicionarAutoC.UseVisualStyleBackColor = false;
            this.btAdicionarAutoC.Click += new System.EventHandler(this.btAdicionarAutoC_Click);
            // 
            // btLimparAutocarro
            // 
            this.btLimparAutocarro.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btLimparAutocarro.BackgroundImage = global::Admin.Properties.Resources.limpar;
            this.btLimparAutocarro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btLimparAutocarro.FlatAppearance.BorderSize = 0;
            this.btLimparAutocarro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLimparAutocarro.Location = new System.Drawing.Point(675, 308);
            this.btLimparAutocarro.Margin = new System.Windows.Forms.Padding(4);
            this.btLimparAutocarro.Name = "btLimparAutocarro";
            this.btLimparAutocarro.Size = new System.Drawing.Size(51, 38);
            this.btLimparAutocarro.TabIndex = 18;
            this.btLimparAutocarro.UseVisualStyleBackColor = false;
            this.btLimparAutocarro.Click += new System.EventHandler(this.btLimparAutocarro_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(80, 85);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(649, 262);
            this.dataGridView2.TabIndex = 17;
            // 
            // btDesativarAuto
            // 
            this.btDesativarAuto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btDesativarAuto.FlatAppearance.BorderSize = 0;
            this.btDesativarAuto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDesativarAuto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btDesativarAuto.ForeColor = System.Drawing.Color.White;
            this.btDesativarAuto.Location = new System.Drawing.Point(426, 379);
            this.btDesativarAuto.Margin = new System.Windows.Forms.Padding(4);
            this.btDesativarAuto.Name = "btDesativarAuto";
            this.btDesativarAuto.Size = new System.Drawing.Size(182, 28);
            this.btDesativarAuto.TabIndex = 16;
            this.btDesativarAuto.Text = "Desativar autocarro";
            this.btDesativarAuto.UseVisualStyleBackColor = false;
            this.btDesativarAuto.Click += new System.EventHandler(this.btDesativarAuto_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 15.75F);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.label3.Location = new System.Drawing.Point(19, 21);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(209, 39);
            this.label3.TabIndex = 14;
            this.label3.Text = "Autocarros";
            // 
            // btEditarAutocarro
            // 
            this.btEditarAutocarro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(34)))), ((int)(((byte)(99)))));
            this.btEditarAutocarro.FlatAppearance.BorderSize = 0;
            this.btEditarAutocarro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEditarAutocarro.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btEditarAutocarro.ForeColor = System.Drawing.Color.White;
            this.btEditarAutocarro.Location = new System.Drawing.Point(25, 379);
            this.btEditarAutocarro.Margin = new System.Windows.Forms.Padding(4);
            this.btEditarAutocarro.Name = "btEditarAutocarro";
            this.btEditarAutocarro.Size = new System.Drawing.Size(163, 28);
            this.btEditarAutocarro.TabIndex = 12;
            this.btEditarAutocarro.Text = "Editar Autocarro";
            this.btEditarAutocarro.UseVisualStyleBackColor = false;
            this.btEditarAutocarro.Click += new System.EventHandler(this.btEditarAutocarro_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::Admin.Properties.Resources.autocarroEsc;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(977, 474);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.flowLayoutPanelMenu);
            this.Controls.Add(this.panelAutocarros);
            this.Controls.Add(this.panelUtilizadores);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "c";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.flowLayoutPanelMenu.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelUtilizadores.ResumeLayout(false);
            this.panelUtilizadores.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panelAutocarros.ResumeLayout(false);
            this.panelAutocarros.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelMenu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btMenu;
        private System.Windows.Forms.Button btSair;
        private System.Windows.Forms.Panel panelUtilizadores;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btCriarUtilizador;
        private System.Windows.Forms.Button btPesquisarUtilizadores;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer transicao;
        private System.Windows.Forms.Timer transicaoLateral;
        private System.Windows.Forms.Button btLimparUtilizadores;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panelAutocarros;
        private System.Windows.Forms.Button btLimparAutocarro;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btDesativarAuto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btEditarAutocarro;
        private System.Windows.Forms.Button btAdicionarAutoC;
        private System.Windows.Forms.Button btCriarRotas;
        private System.Windows.Forms.Button btDesativarUtilizador;
        private System.Windows.Forms.Button btEditarUtilizadores;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btUtilizadores;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btAutocarros;
    }
}